# NOVA TV Launcher

Launcher nativo e minimalista para **Android TV / Google TV** (Android 8.0 ou superior). O projeto foi pensado para funcionar com o controle remoto e usar o mínimo possível de recursos.

## O que já está implementado

- Tela inicial em paisagem, com relógio, data e saudação em português.
- Linha de favoritos e grade dos aplicativos instalados que oferecem atividade para Android TV.
- Navegação por controle remoto (D-pad e OK), com destaque visual do item em foco.
- Segurar **OK** em um aplicativo adiciona ou remove esse app dos favoritos.
- Atalhos para fontes de vídeo, Wi-Fi e configurações do Android.
- Seletor de HDMI/entradas por `TvInputManager` e reprodução por `TvView`, quando o fabricante disponibiliza essas entradas para apps comuns.
- Opção para escolher o launcher padrão ou voltar ao launcher original.

## Leveza e privacidade

- Java nativo e componentes padrão do Android.
- Sem WebView, bibliotecas de interface, imagens de wallpaper, fontes externas ou animações pesadas.
- Sem permissão `INTERNET`, analytics ou rastreadores.
- Sem serviços em segundo plano. O relógio só atualiza enquanto a tela inicial está aberta.
- Ícones são carregados dos próprios aplicativos já instalados na TV.

O launcher substitui a **tela inicial**; ele não desinstala aplicativos da fabricante, não desativa anúncios dentro do sistema e não aumenta a capacidade física de RAM ou do processador. O ganho de fluidez depende do peso do launcher original e do hardware da TV.

## Como compilar

### Android Studio

1. Abra a pasta `nova_tv_launcher` no Android Studio.
2. Aguarde a sincronização do Gradle e instale o Android SDK Platform 35, caso seja solicitado.
3. Selecione **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

O projeto usa JDK 17, Android Gradle Plugin 8.9.1, Gradle 8.11.1, `minSdk 26` e `targetSdk 35`.

### Compilar sem configurar o computador (GitHub Actions)

1. Crie um repositório no GitHub e envie os arquivos desta pasta.
2. Abra a aba **Actions** e permita a execução dos workflows, se o GitHub pedir.
3. Execute **Build NOVA TV APK**.
4. Ao terminar, abra a execução e baixe o artefato **nova-tv-debug-apk**. Dentro dele estará `app-debug.apk`.

O workflow instala o Android SDK e compila o APK de depuração; ele não instala nada na sua TV.

## Instalar e escolher como tela inicial

1. Transfira `app-debug.apk` para a TV e instale-o usando um gerenciador de arquivos.
2. Pressione o botão **Home/Início** do controle remoto.
3. Quando aparecer a escolha de tela inicial, selecione **NOVA TV** e escolha **Sempre**.
4. Para voltar, abra as configurações de apps/tela inicial da TV e escolha o launcher original. Também existe o atalho **Ajustes → Escolher launcher padrão** dentro da NOVA TV.

Os nomes dos menus variam entre fabricantes. Algumas TVs não mostram o seletor de tela inicial ou impedem aplicativos de terceiros de abrir as entradas HDMI; nesses casos, use o menu/tecla `INPUT` ou `SOURCE` do próprio controle.

## Observações de compatibilidade

- Feito para Android TV e Google TV com Android 8.0 (API 26) ou superior.
- Não é um launcher para celular, tablet, Windows ou tvOS.
- A lista de apps usa atividades `LEANBACK_LAUNCHER`; alguns fabricantes podem esconder aplicativos ou expor apps de maneira diferente.
- O acesso a HDMI depende do serviço de TV e das permissões implementadas pela fabricante. Se não estiver disponível, o app mostra um aviso em vez de prometer uma troca que a TV não permite.
- O botão de rede abre o painel de conectividade quando o sistema oferece esse painel; caso contrário, tenta abrir as configurações de Wi-Fi.

## Estrutura

- `app/src/main/java/com/nova/tvlauncher/MainActivity.java` — tela inicial, apps, favoritos e atalhos.
- `app/src/main/java/com/nova/tvlauncher/InputActivity.java` — reprodução de entradas compatíveis.
- `app/src/main/AndroidManifest.xml` — declaração de app para TV e atividade HOME.

