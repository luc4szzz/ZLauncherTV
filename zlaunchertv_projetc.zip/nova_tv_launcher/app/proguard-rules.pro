# No external libraries are used by NOVA TV.
