package com.nova.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * NOVA TV - a small, native Android TV home screen.
 * No WebView, network permission, third-party libraries or background services.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "nova_tv_settings";
    private static final String KEY_FAVORITES = "favorite_packages";
    private static final int COLOR_BG = Color.rgb(7, 17, 31);
    private static final int COLOR_TILE = Color.rgb(17, 31, 49);
    private static final int COLOR_TILE_FOCUS = Color.rgb(30, 76, 118);
    private static final int COLOR_TEXT = Color.rgb(242, 246, 251);
    private static final int COLOR_MUTED = Color.rgb(151, 169, 190);
    private static final int COLOR_ACCENT = Color.rgb(109, 177, 244);

    private final Handler handler = new Handler();
    private final ArrayList<AppEntry> installedApps = new ArrayList<>();
    private final Set<String> favoritePackages = new HashSet<>();
    private SharedPreferences preferences;
    private LinearLayout page;
    private TextView clockText;
    private TextView dateText;
    private TextView greetingText;
    private Runnable clockRunnable;
    private int columns = 4;

    private static class AppEntry {
        final String title;
        final String packageName;
        final ComponentName component;
        final Drawable icon;

        AppEntry(String title, String packageName, ComponentName component, Drawable icon) {
            this.title = title;
            this.packageName = packageName;
            this.component = component;
            this.icon = icon;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        hideSystemBars();
        calculateColumns();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        loadApps();
        loadFavorites();
        buildScreen();
        startClock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopClock();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        window.setStatusBarColor(COLOR_BG);
        window.setNavigationBarColor(COLOR_BG);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private void calculateColumns() {
        float density = getResources().getDisplayMetrics().density;
        float widthDp = getResources().getDisplayMetrics().widthPixels / density;
        float available = widthDp - 112f;
        columns = Math.max(2, Math.min(6, (int) (available / 252f)));
    }

    private void loadApps() {
        installedApps.clear();
        PackageManager pm = getPackageManager();
        Intent tvIntent = new Intent(Intent.ACTION_MAIN);
        tvIntent.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<ResolveInfo> results = pm.queryIntentActivities(tvIntent, 0);

        // A few devices expose some TV-compatible apps with the regular launcher category only.
        if (results == null || results.isEmpty()) {
            Intent regularIntent = new Intent(Intent.ACTION_MAIN);
            regularIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            results = pm.queryIntentActivities(regularIntent, 0);
        }

        LinkedHashMap<String, AppEntry> unique = new LinkedHashMap<>();
        if (results != null) {
            for (ResolveInfo info : results) {
                if (info == null || info.activityInfo == null) continue;
                String packageName = info.activityInfo.packageName;
                if (packageName == null || packageName.equals(getPackageName())) continue;
                ComponentName component = new ComponentName(packageName, info.activityInfo.name);
                String key = component.flattenToString();
                if (unique.containsKey(key)) continue;
                try {
                    String title = String.valueOf(info.loadLabel(pm));
                    Drawable icon = info.loadIcon(pm);
                    unique.put(key, new AppEntry(title, packageName, component, icon));
                } catch (Exception ignored) {
                    // An app can be removed while the package list is being read.
                }
            }
        }

        installedApps.addAll(unique.values());
        Collections.sort(installedApps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry first, AppEntry second) {
                return first.title.compareToIgnoreCase(second.title);
            }
        });
    }

    private void loadFavorites() {
        favoritePackages.clear();
        if (preferences.contains(KEY_FAVORITES)) {
            Set<String> stored = preferences.getStringSet(KEY_FAVORITES, new HashSet<String>());
            if (stored != null) favoritePackages.addAll(stored);
        } else {
            for (int i = 0; i < Math.min(4, installedApps.size()); i++) {
                favoritePackages.add(installedApps.get(i).packageName);
            }
            saveFavorites();
        }
        // Remove packages that are no longer installed.
        Set<String> installed = new HashSet<>();
        for (AppEntry app : installedApps) installed.add(app.packageName);
        favoritePackages.retainAll(installed);
    }

    private void saveFavorites() {
        preferences.edit().putStringSet(KEY_FAVORITES, new HashSet<>(favoritePackages)).apply();
    }

    private void buildScreen() {
        float density = getResources().getDisplayMetrics().density;
        FrameLayoutBuilder builder = new FrameLayoutBuilder(this);
        setContentView(builder.frame);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        builder.frame.addView(scroll, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(54), dp(30), dp(54), dp(54));
        scroll.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addHeader();
        addSectionTitle("FAVORITOS", "Segure OK em um app para editar seus favoritos");
        addFavorites();
        addSectionTitle("APLICATIVOS", installedApps.size() + " apps encontrados na TV");
        addAppGrid();
        addFooter();

        // Place focus on the first useful control for remote navigation.
        page.post(new Runnable() {
            @Override public void run() {
                View target = page.findFocus();
                if (target == null) {
                    View first = findFirstFocusable(page);
                    if (first != null) first.requestFocus();
                }
            }
        });
    }

    private void addHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(0, 0, 0, dp(34));
        page.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout timeBlock = new LinearLayout(this);
        timeBlock.setOrientation(LinearLayout.VERTICAL);
        timeBlock.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(timeBlock, new LinearLayout.LayoutParams(0, dp(104), 1f));

        greetingText = text("BOA TARDE", 13, COLOR_MUTED, Typeface.BOLD);
        greetingText.setLetterSpacing(0.22f);
        timeBlock.addView(greetingText);

        LinearLayout dateLine = new LinearLayout(this);
        dateLine.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams dateLineParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dateLineParams.topMargin = dp(5);
        timeBlock.addView(dateLine, dateLineParams);

        clockText = text("16:54", 48, COLOR_TEXT, Typeface.NORMAL);
        clockText.setIncludeFontPadding(false);
        dateLine.addView(clockText);

        View separator = new View(this);
        separator.setBackgroundColor(0x557D91AA);
        LinearLayout.LayoutParams separatorParams = new LinearLayout.LayoutParams(dp(1), dp(38));
        separatorParams.leftMargin = dp(20);
        separatorParams.rightMargin = dp(20);
        dateLine.addView(separator, separatorParams);

        dateText = text("QUARTA-FEIRA, 11 DE NOVEMBRO", 14, COLOR_MUTED, Typeface.NORMAL);
        dateText.setLetterSpacing(0.08f);
        dateLine.addView(dateText);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        header.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        actions.addView(actionChip("▣", "FONTES", new Runnable() {
            @Override public void run() { openInputs(); }
        }));
        actions.addView(actionChip("⌁", "WI-FI", new Runnable() {
            @Override public void run() { openNetworkSettings(); }
        }));
        actions.addView(actionChip("⚙", "AJUSTES", new Runnable() {
            @Override public void run() { showSettings(); }
        }));
    }

    private View actionChip(String symbol, String label, final Runnable action) {
        LinearLayout chip = new LinearLayout(this);
        chip.setGravity(Gravity.CENTER);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setFocusable(true);
        chip.setClickable(true);
        chip.setPadding(dp(18), 0, dp(18), 0);
        chip.setBackground(tileBackground(false, true));
        chip.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View view, boolean focused) {
                view.setBackground(tileBackground(focused, true));
            }
        });
        chip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { action.run(); }
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(54));
        params.leftMargin = dp(10);
        chip.setLayoutParams(params);

        TextView icon = text(symbol, 19, COLOR_TEXT, Typeface.BOLD);
        chip.addView(icon);
        TextView title = text(label, 14, COLOR_TEXT, Typeface.BOLD);
        title.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.leftMargin = dp(10);
        chip.addView(title, titleParams);
        return chip;
    }

    private void addSectionTitle(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = dp(10);
        rowParams.bottomMargin = dp(14);
        page.addView(row, rowParams);

        TextView heading = text(title, 17, COLOR_TEXT, Typeface.BOLD);
        heading.setLetterSpacing(0.12f);
        row.addView(heading);

        TextView detail = text(subtitle, 12, COLOR_MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailParams.leftMargin = dp(17);
        row.addView(detail, detailParams);
    }

    private void addFavorites() {
        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        horizontal.setClipToPadding(false);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(132));
        scrollParams.bottomMargin = dp(30);
        page.addView(horizontal, scrollParams);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        horizontal.addView(row, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int count = 0;
        for (AppEntry app : installedApps) {
            if (!favoritePackages.contains(app.packageName)) continue;
            View tile = appTile(app, true, count);
            LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(dp(270), dp(116));
            tileParams.leftMargin = dp(6);
            tileParams.rightMargin = dp(6);
            row.addView(tile, tileParams);
            count++;
        }

        if (count == 0) {
            TextView empty = text("Nenhum favorito ainda. Segure OK em um app abaixo para adicionar.",
                    15, COLOR_MUTED, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    private void addAppGrid() {
        if (installedApps.isEmpty()) {
            TextView empty = text("Nenhum aplicativo de TV foi encontrado.", 16, COLOR_MUTED, Typeface.NORMAL);
            empty.setPadding(0, dp(18), 0, dp(18));
            page.addView(empty);
            return;
        }

        LinearLayout currentRow = null;
        int inRow = 0;
        for (AppEntry app : installedApps) {
            if (currentRow == null || inRow >= columns) {
                currentRow = new LinearLayout(this);
                currentRow.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(116));
                rowParams.bottomMargin = dp(13);
                page.addView(currentRow, rowParams);
                inRow = 0;
            }
            View tile = appTile(app, false, inRow);
            LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            tileParams.leftMargin = dp(6);
            tileParams.rightMargin = dp(6);
            currentRow.addView(tile, tileParams);
            inRow++;
        }

        if (currentRow != null && inRow < columns) {
            for (int i = inRow; i < columns; i++) {
                View spacer = new View(this);
                currentRow.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
            }
        }
    }

    private View appTile(final AppEntry app, boolean favorite, int position) {
        LinearLayout tile = new LinearLayout(this);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setPadding(dp(16), dp(12), dp(14), dp(12));
        tile.setFocusable(true);
        tile.setClickable(true);
        tile.setBackground(tileBackground(false, false));
        tile.setContentDescription(app.title + (favorite ? ", favorito" : ""));
        tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View view, boolean focused) {
                view.setBackground(tileBackground(focused, false));
                view.setScaleX(focused ? 1.025f : 1f);
                view.setScaleY(focused ? 1.025f : 1f);
            }
        });
        tile.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { launchApp(app); }
        });
        tile.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View view) {
                toggleFavorite(app);
                return true;
            }
        });

        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (app.icon != null) icon.setImageDrawable(app.icon);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(52), dp(52));
        iconParams.rightMargin = dp(15);
        tile.addView(icon, iconParams);

        LinearLayout labels = new LinearLayout(this);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        labels.setOrientation(LinearLayout.VERTICAL);
        tile.addView(labels, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = text(app.title, 17, COLOR_TEXT, Typeface.BOLD);
        title.setMaxLines(2);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(title);

        if (favorite) {
            TextView tag = text("FAVORITO", 10, COLOR_MUTED, Typeface.BOLD);
            tag.setLetterSpacing(0.10f);
            LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tagParams.topMargin = dp(4);
            labels.addView(tag, tagParams);
        }

        return tile;
    }

    private void addFooter() {
        TextView footer = text("NOVA TV  •  LEVE, OFFLINE E FEITA PARA CONTROLE REMOTO",
                10, 0x887F98B2, Typeface.BOLD);
        footer.setLetterSpacing(0.08f);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        params.topMargin = dp(18);
        page.addView(footer, params);
    }

    private void launchApp(AppEntry app) {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            intent.setComponent(app.component);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception firstError) {
            try {
                Intent fallback = getPackageManager().getLaunchIntentForPackage(app.packageName);
                if (fallback != null) startActivity(fallback);
                else Toast.makeText(this, "Não foi possível abrir " + app.title, Toast.LENGTH_SHORT).show();
            } catch (Exception secondError) {
                Toast.makeText(this, "Não foi possível abrir este aplicativo.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void toggleFavorite(AppEntry app) {
        if (favoritePackages.contains(app.packageName)) {
            favoritePackages.remove(app.packageName);
            Toast.makeText(this, app.title + " removido dos favoritos", Toast.LENGTH_SHORT).show();
        } else {
            favoritePackages.add(app.packageName);
            Toast.makeText(this, app.title + " adicionado aos favoritos", Toast.LENGTH_SHORT).show();
        }
        saveFavorites();
        buildScreen();
    }

    private void openNetworkSettings() {
        try {
            Intent intent;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                intent = new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY);
            } else {
                intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
            }
            startActivity(intent);
        } catch (Exception error) {
            try {
                startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
            } catch (Exception ignored) {
                openSystemSettings();
            }
        }
    }

    private void openInputs() {
        try {
            TvInputManager manager = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
            if (manager == null) throw new IllegalStateException("TV Input Manager indisponível");
            List<TvInputInfo> all = manager.getTvInputList();
            ArrayList<TvInputInfo> inputs = new ArrayList<>();
            ArrayList<String> labels = new ArrayList<>();
            for (TvInputInfo info : all) {
                if (info == null || !info.isPassthroughInput()) continue;
                try {
                    if (info.isHidden(this)) continue;
                } catch (Exception ignored) { }
                CharSequence custom = info.loadCustomLabel(this);
                CharSequence normal = info.loadLabel(this);
                String name = custom != null && custom.length() > 0
                        ? custom.toString() : (normal != null ? normal.toString() : "Entrada de vídeo");
                inputs.add(info);
                labels.add(name);
            }
            if (inputs.isEmpty()) {
                Toast.makeText(this,
                        "Esta TV não disponibilizou as entradas para apps. Use INPUT/SOURCE no controle.",
                        Toast.LENGTH_LONG).show();
                return;
            }
            String[] options = labels.toArray(new String[0]);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Escolher entrada")
                    .setItems(options, (d, which) -> {
                        Intent intent = new Intent(this, InputActivity.class);
                        intent.putExtra(InputActivity.EXTRA_INPUT_ID, inputs.get(which).getId());
                        intent.putExtra(InputActivity.EXTRA_INPUT_NAME, labels.get(which));
                        startActivity(intent);
                    })
                    .setNegativeButton("VOLTAR", null)
                    .create();
            dialog.show();
        } catch (Exception error) {
            Toast.makeText(this,
                    "A seleção de entradas depende do sistema da TV. Use INPUT/SOURCE no controle.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showSettings() {
        String[] options = {
                "Escolher launcher padrão",
                "Configurações do Android",
                "Restaurar favoritos padrão",
                "Sobre a NOVA TV"
        };
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("NOVA TV · Ajustes")
                .setItems(options, (d, which) -> {
                    if (which == 0) openHomeSettings();
                    else if (which == 1) openSystemSettings();
                    else if (which == 2) {
                        preferences.edit().remove(KEY_FAVORITES).apply();
                        loadFavorites();
                        buildScreen();
                        Toast.makeText(this, "Favoritos restaurados", Toast.LENGTH_SHORT).show();
                    } else {
                        new AlertDialog.Builder(this)
                                .setTitle("NOVA TV")
                                .setMessage("Uma tela inicial nativa e minimalista para Android TV.\n\nSem WebView, sem anúncios, sem conta, sem permissão de internet e sem serviços em segundo plano.\n\nVersão 1.0.0")
                                .setPositiveButton("OK", null)
                                .show();
                    }
                })
                .setNegativeButton("FECHAR", null)
                .create();
        dialog.show();
    }

    private void openHomeSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception error) {
            openSystemSettings();
        }
    }

    private void openSystemSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Configurações do sistema indisponíveis.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startClock() {
        stopClock();
        clockRunnable = new Runnable() {
            @Override public void run() {
                updateClock();
                handler.postDelayed(this, 30_000L);
            }
        };
        handler.post(clockRunnable);
    }

    private void stopClock() {
        if (clockRunnable != null) handler.removeCallbacks(clockRunnable);
        clockRunnable = null;
    }

    private void updateClock() {
        if (clockText == null || dateText == null || greetingText == null) return;
        Date now = new Date();
        Locale locale = new Locale("pt", "BR");
        clockText.setText(new SimpleDateFormat("HH:mm", locale).format(now));
        String date = new SimpleDateFormat("EEEE, d 'DE' MMMM", locale).format(now);
        if (date.length() > 0) date = date.substring(0, 1).toUpperCase(locale) + date.substring(1);
        dateText.setText(date.toUpperCase(locale));
        int hour = Integer.parseInt(new SimpleDateFormat("H", locale).format(now));
        String greeting = hour < 12 ? "BOM DIA" : (hour < 18 ? "BOA TARDE" : "BOA NOITE");
        greetingText.setText(greeting);
    }

    private TextView text(String value, float size, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.create("sans-serif", style));
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setIncludeFontPadding(false);
        return view;
    }

    private GradientDrawable tileBackground(boolean focused, boolean chip) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(dp(chip ? 28 : 18));
        if (focused) {
            drawable.setColor(COLOR_TILE_FOCUS);
            drawable.setStroke(dp(2), 0xFFB5DCFF);
        } else {
            drawable.setColor(chip ? 0xAA18283C : COLOR_TILE);
            drawable.setStroke(dp(1), 0x553D5875);
        }
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private View findFirstFocusable(View view) {
        if (view.isFocusable() && view.getVisibility() == View.VISIBLE) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View found = findFirstFocusable(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showSettings();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private static class FrameLayoutBuilder {
        final android.widget.FrameLayout frame;
        FrameLayoutBuilder(Context context) {
            frame = new android.widget.FrameLayout(context);
            GradientDrawable background = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.rgb(5, 13, 25), Color.rgb(9, 29, 50), Color.rgb(6, 15, 28)});
            frame.setBackground(background);
        }
    }
}
