package com.nova.tvlauncher;

import android.app.Activity;
import android.media.tv.TvContract;
import android.media.tv.TvView;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

/** Displays a passthrough TV input (for example HDMI) when the device permits it. */
public class InputActivity extends Activity {
    public static final String EXTRA_INPUT_ID = "nova.input_id";
    public static final String EXTRA_INPUT_NAME = "nova.input_name";
    private TvView tvView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        String inputId = getIntent().getStringExtra(EXTRA_INPUT_ID);
        if (inputId == null || inputId.trim().isEmpty()) {
            finish();
            return;
        }

        tvView = new TvView(this);
        tvView.setFocusable(true);
        tvView.setFocusableInTouchMode(true);
        setContentView(tvView);
        tvView.setCallback(new TvView.TvInputCallback() {
            @Override
            public void onConnectionFailed(String failedInputId) {
                Toast.makeText(InputActivity.this,
                        "Não foi possível conectar a esta entrada.", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        try {
            Uri channel = TvContract.buildChannelUriForPassthroughInput(inputId);
            tvView.tune(inputId, channel);
        } catch (Exception error) {
            Toast.makeText(this, "Esta entrada não está disponível para aplicativos.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (tvView != null) tvView.reset();
    }
}
